/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/06 10:35:02 by akouame           #+#    #+#             */
/*   Updated: 2021/10/06 10:37:21 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	i;
	int	k;

	i = 2;
	k = nb / 2;
	if (nb <= 2)
		return (2);
	while (i <= k)
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{
	if (nb <= 2)
		return (2);
	else if (nb >= 2147483640 && nb <= 2147483647)
		return (2147483647);
	while (1)
	{
		if (ft_is_prime(nb) == 0)
			nb = nb + 1;
		else if (ft_is_prime(nb) == 1)
			return (nb);
	}
}
