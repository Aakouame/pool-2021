/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/06 10:10:16 by akouame           #+#    #+#             */
/*   Updated: 2021/10/06 10:12:08 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_fibonacci(int index)
{
	int	k;

	if (index < 0)
		k = -1;
	else if (index == 0)
		k = 0;
	else if (index == 1)
		k = 1;
	else
		k = ft_fibonacci(index - 1) + ft_fibonacci(index - 2);
	return (k);
}
