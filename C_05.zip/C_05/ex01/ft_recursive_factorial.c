/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/06 10:05:29 by akouame           #+#    #+#             */
/*   Updated: 2021/10/06 10:06:18 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	r;

	r = 1;
	if (nb <= 1 && nb >= 0)
		return (1);
	else if (nb < 0)
		return (0);
	if (nb != 0)
	{
		r = nb * ft_recursive_factorial(nb - 1);
	}
	return (r);
}
