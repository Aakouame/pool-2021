/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/25 10:40:18 by akouame           #+#    #+#             */
/*   Updated: 2021/09/26 19:06:12 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char a)
{
	write (1, &a, 1);
}

void	ft_putnbr(int nb)
{
	long	a;

	a = nb;
	if (a == -2147483648)
	{
		write(1, "-2147483648", 11);
	}
	else if (a < 0)
	{
		ft_putchar('-');
		ft_putnbr (a * (-1));
	}
	else if (a < 10)
	{
		ft_putchar(a + '0');
	}
	else
	{
		ft_putnbr(a / 10);
		ft_putnbr(a % 10);
	}
}
