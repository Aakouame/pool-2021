/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/25 09:25:57 by akouame           #+#    #+#             */
/*   Updated: 2021/09/26 15:38:36 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char a)
{
	write(1, &a, 1);
}

void	ft_print(int a, int b)
{
	char	a1;
	char	a2;
	char	b1;
	char	b2;

	a1 = a;
	a2 = a;
	b1 = b;
	b2 = b;
	ft_putchar(a1 / 10 + '0');
	ft_putchar(a2 % 10 + '0');
	write(1, " ", 1);
	ft_putchar(b1 / 10 + '0');
	ft_putchar(b2 % 10 + '0');
}

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	b = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			ft_print(a, b);
			if (a == 98 && b == 99)
			{
				break ;
			}
			write(1, ", ", 2);
			b++;
		}
		a++;
	}
}
