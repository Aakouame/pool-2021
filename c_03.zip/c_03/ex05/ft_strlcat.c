/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/03 10:40:22 by akouame           #+#    #+#             */
/*   Updated: 2021/10/03 12:43:04 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_next(char *s)
{
	unsigned int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	k;

	k = 0;
	i = ft_next(dest);
	j = ft_next(src);
	if (i >= size)
		j = j + size;
	else
		j = i + j;
	if (size == 0)
		return (j);
	while (src[k] && i < (size - 1))
	{
		dest[i] = src[k];
		k++;
		i++;
	}
	dest[i] = '\0';
	return (j);
}
