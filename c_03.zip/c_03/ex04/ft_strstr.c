/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/03 10:39:52 by akouame           #+#    #+#             */
/*   Updated: 2021/10/03 10:40:05 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	j = 0;
	while (to_find[i])
		i++;
	if (i == 0)
		return (str);
	while (str[j])
	{
		k = 0;
		while (k < i)
		{
			if (str[j + k] != to_find[k])
				break ;
			k++;
		}
		if (k == i)
			return (1);
		j++;
	}
	return (0);
}
