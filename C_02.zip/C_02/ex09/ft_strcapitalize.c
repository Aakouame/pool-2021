/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/30 12:10:39 by akouame           #+#    #+#             */
/*   Updated: 2021/09/30 12:10:54 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	ft_strupcase(char x, char y)
{
	if ((x >= 0 && x <= 47) || (x >= 91 && x <= 96))
	{
		if (y >= 'a' && y <= 'z')
		{
			y = y - 32;
		}
	}
	else if ((x >= 58 && x <= 64) || (x >= 123))
	{
		if (y >= 'a' && y <= 'z')
		{
			y = y - 32;
		}
	}
	return (y);
}

char	ft_strlowcase(char x, char w)
{
	if (x >= 'A' && x <= 'Z')
	{
		if ((w >= 'A' && w <= 'Z') || (w >= 'a' && w <= 'z'))
		{
			x = x + 32;
		}
		else if (w >= '0' && w <= '9')
		{
			x = x + 32;
		}
	}
	return (x);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	if (str[0] >= 'a' && str[0] <= 'z')
	{
		str[0] = str[0] - 32;
		i++;
	}
	while (str[i])
	{
		str[i + 1] = ft_strupcase(str[i], str[i + 1]);
		str[i] = ft_strlowcase(str[i], str[i - 1]);
		i++;
	}
	return (str);
}
