/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/12 16:04:42 by akouame           #+#    #+#             */
/*   Updated: 2021/10/12 16:32:09 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_my_atoi(char *str, char *base)
{
	int		i;
	int		j;
	char	x;

	i = 0;
	while ((str[i] == ' ') || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '-' || str[i] == '+')
		i++;
	while (str[i])
	{
		j = 0;
		while (base[j])
		{
			if (base[j] == str[i])
				x = str[i];
			j++;
		}
		if (str[i] != x)
			break ;
		i++;
	}
	return (i);
}

int	ft_signe(char *str)
{
	int	i;
	int	s;

	i = 0;
	s = 1;
	while ((str[i] == ' ' || str[i] == '\n' || str[i] == '\t'
			|| str[i] == '\f' || str[i] == '\v' || str[i] == '\r'))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			s = s * (-1);
		i++;
	}
	return (s);
}

int	ft_verif_base(char *base)
{
	int	j;
	int	k;

	k = 0;
	while (base[k])
		k++;
	if (k <= 1)
		return (0);
	k = 0;
	while (base[k])
	{
		if ((base[k] == ' ' || base[k] == '\n' || base[k] == '\t'
				|| base[k] == '\f' || base[k] == '\v' || base[k] == '\r')
			|| (base[k] == '+' || base[k] == '-'))
			return (0);
		j = k + 1;
		while (base[j])
		{
			if (base[k] == base[j])
				return (0);
			j++;
		}
		k++;
	}
	return (1);
}

int	ft_indix(char x, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == x)
			return (i);
		i++;
	}
	return (0);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	r;
	int	l_base;
	int	j;
	int	p;

	r = 0;
	i = 0;
	p = 1;
	if (ft_verif_base(base))
	{
		while (base[i++])
			l_base = i;
		i = 0;
		while ((str[i++] == ' ') || (str[i] >= 9 && str[i] <= 13))
			while (str[i] == '-' || str[i] == '+')
				i++;
		j = 0;
		while (i++ <= ft_my_atoi(str, base))
		{
			r = r + ft_indix(str[ft_my_atoi(str, base) - 1 - j++], base) * p;
			p = p * l_base ;
		}
	}
	return (r * ft_signe(str));
}
