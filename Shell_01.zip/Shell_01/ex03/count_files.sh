#!/bin/bash
find . -type d -o -type f | wc -l | tr -d " "
