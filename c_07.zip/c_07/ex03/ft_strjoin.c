/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/12 09:19:04 by akouame           #+#    #+#             */
/*   Updated: 2021/10/12 09:32:24 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_add(int size, char **strs, char *sep, char *tab)
{
	int	l;
	int	i;
	int	j;

	i = 0;
	l = 0;
	while (i < size && strs[i])
	{
		j = 0;
		while (strs[i][j] != '\0')
		{
			tab[l] = strs[i][j];
			l++;
			j++;
		}
		j = 0;
		if (strs[i + 1])
		{
			while (sep[j] && i + 1 < size)
				tab[l++] = sep[j++];
		}
		i++;
	}
	return (tab);
}

int	ft_lent(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*tab;
	int		l;

	tab = (char *)malloc(sizeof(char) * size);
	if (size <= 0)
	{
		tab = NULL;
		return (tab);
	}
	tab = ft_add(size, strs, sep, tab);
	l = ft_lent(tab);
	tab[l] = '\0';
	return (tab);
}
