/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/12 09:40:41 by akouame           #+#    #+#             */
/*   Updated: 2021/10/12 09:46:52 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*tab;
	int	i;
	int	l;

	l = max - min;
	if (l <= 0)
		return (0);
	tab = (int *)malloc(sizeof(int) * l);
	if (!tab)
		return (-1);
	i = 1 ;
	tab[0] = min;
	while (i < l)
	{
		tab[i] = tab[i - 1] + 1;
		i++;
	}
	*range = tab;
	return (l);
}
