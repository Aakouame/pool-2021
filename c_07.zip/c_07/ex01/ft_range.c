/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akouame <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/12 09:36:35 by akouame           #+#    #+#             */
/*   Updated: 2021/10/12 09:40:12 by akouame          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*tab;
	int	k;

	i = 1;
	tab = NULL;
	k = max - min;
	if (k <= 0)
		return (0);
	tab = malloc(sizeof(int) * k);
	tab[0] = min;
	while (i < k)
	{
		tab[i] = tab[i - 1] + 1;
		i++;
	}
	return (tab);
}
